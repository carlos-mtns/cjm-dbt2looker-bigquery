from setuptools import setup, find_packages

setup(
    name='cjm-dbt2looker-bigquery',
    version='0.14.0',
    packages=find_packages(),
    install_requires=[

    ],
)